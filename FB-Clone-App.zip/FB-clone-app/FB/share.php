<?php
if(isset($_REQUEST['id']))
{
session_start();
$con=mysqli_connect('localhost','root','')or die("could not connect server".mysql_error($con));
mysqli_select_db($con,'mydb')or die("could not connect database".mysql_error($con));
$id=$_REQUEST['id'];

// echo "<br>id is = $id";
$u=$_SESSION['login'];
$d=date('D/M/Y');
date_default_timezone_set('asia/calcutta');
$t=date('h/i/s');


 $q="select * from post where pid=$id";
 $rs=mysqli_query($con,$q)or die("could not execute query ".mysqli_error($con));
 $x=mysqli_fetch_array($rs);
 
$s="insert into post (uname,dt,text,img) values ('$u','$d  $t','$x[3]','$x[4]')";
 $rs1=mysqli_query($con,$s)or die("Could not execute  ".mysqli_error($con));
//  if($rs1>0)
// 	 echo "Post Share";
//  else
// 	 echo "<br>could not  Share Post";
 
 
header('location:home.php');
}
?>