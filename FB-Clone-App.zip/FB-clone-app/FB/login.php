<html>
<head>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</head>
<body style="background:#e8ebf0">
<?php
Ob_start();
?>

<div class="cont" style="height:600px">
<div class="row" style="height:120px"></div>
<!--left side-->
<div class="row" style="height:450px">
<div class="col-md-6"><br><br><br><h1 style="margin-left:20px; color:blue; font-size:70px">&nbsp; &nbsp; <strong>facebook</strong></h1>
<h3 style="margin-left:100px">Connect with friends and the world around you on facebook.</h3>
</div>

<!--right side-->
<div class="col-md-5" style="padding-top:0px">
<center>

<div class="card" style="background:white; margin-left:100px; width:23rem; height:20rem; border-radius:10px">
<div class="card-body">
<form>
<div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Email or Phone Number" name="EM">
</div>

<div class="input-group mb-3">
 <input type="password" class="form-control" placeholder="Password" name="PWD" >
</div>

<div class="input-group mb-3">
 <input type="submit" class="form-control" value="LogIn" name="login" style="background:blue;color:white">
</div>

</form>

<center><a href="forgot" style="text-decoration:none"> Forgot Password? </a></center><hr>

<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal1" style="background:#17eb3a; color:white">
  Create New Account
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal1" tabindex="-1" >
  <div class="modal-dialog">
    <div class="modal-content"><!--3-->
	 
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLabel" ><b>Sign up</b></h3>
		<br><p>It's quick and easy.</p>
		
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
	  
      <div class="modal-body">
	  <form method="post" enctype="multipart/form-data">

	     <div class="row">
            <div class="col">
              <input type="text" class="form-control" placeholder="First name" name="fn">
            </div>
            <div class="col">
              <input type="text" class="form-control" placeholder="Last name" name="ln">
            </div>
         </div><br>
		 
         <div class="row">
           <div class="col">
              <input type="text" class="form-control" placeholder="Mobile number or email address" name="em">
           </div>
		   </div><br>

        <div class="row">
            <div class="col">
               <input type="text" class="form-control" placeholder="New password" name="np">
             </div></div>
	   <br>
	   
	   <p style="text-align:left">date of birth</p>
	         <div class="row">
               <div class="col">
               <select class="form-control" name="d">
	<?php
	for($i=1;$i<=31;$i++)
	{
		echo "<option value='$i'>$i</option>";
		
	}
	?>
	</select>
  </div>
  <div class="col">
    <select class="form-control" name="m">
	<option value="January">January</option>
	<option value="February">February</option>
	<option value="March">March</option>
	<option value="April">April</option>
	<option value="May">May</option>
	<option value="June">June</option>
	<option value="July">July</option>
	<option value="August">August</option>
	<option value="September">September</option>
	<option value="October">October</option>
	<option value="November">November</option>
	<option value="December">December</option>
	</select>
  </div>
  
    <div class="col">
    <select class="form-control" name="y">
	<?php
	for($i=1950;$i<=2021;$i++)
	{
		echo "<option value='$i'>$i</option>";
	}
	?>
	</select>
  </div></div>
  <br>
  <div class="row">
    <div class="col">
Male&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<input value="Male" type="radio" name="gen" ></div>

<div class="col">
Female&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="gen" value="Female"></div>

<div class="col">
Custom&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="gen" value="Custom"></div>
 </div>
<br>

<div class="row">
  <div class="col" style="text-align:left">Select File&nbsp;<input type="file" name="file"></div>
</div><br>
<input type="submit" class="form-control" data-bs-dismiss="modal" value="Sign up" name="signup" style="color:white; background:blue; width:130px">
</form>
</div><!--Modelbody-->

      
  <div class="modal-footer" >
    <div class="row"><div class="col" style="padding-left:0px">
  </div></div>

</form>
     </div>
	 
    </div>
  </div>
</div>

</div><!--cardbody-->
</div><!--card-->

<br>
<p style="margin-left:100px"><b>Create a page</b> for a celebrity,brand or business.</p>
</center>


</div><!--col-->

</div><!--row-->
</div><!--cont-->
</body>
</html>
<?php
if(isset($_REQUEST['signup']))
{
	$con=mysqli_connect('localhost','root','')or die("could not connect server".mysql_error($con));
mysqli_select_db($con,'mydb')or die("could not connect database".mysql_error($con));

	$fn=$_REQUEST['fn'];
	$ln=$_REQUEST['ln'];
	$em=$_REQUEST['em'];
	$np=$_REQUEST['np'];
	$d=$_REQUEST['d'];
	$m=$_REQUEST['m'];
	$y=$_REQUEST['y'];
	$gen=$_REQUEST['gen'];
	$img=$_FILES['file']['name'];
	$dob=$d.$m.$y;
	if(move_uploaded_file($_FILES['file']['tmp_name'],$_FILES['file']['name']));
	{
	$q="insert into signup values('$fn','$ln','$em','$np','$dob','$gen','$img')";
$rs=mysqli_query($con,$q)or die("could not execute query".mysql_error($con));
}
	
}
if(isset($_REQUEST['login']))
{
	$con=mysqli_connect('localhost','root','')or die("could not connect server".mysql_error($con));
mysqli_select_db($con,'mydb')or die("could not connect database".mysql_error($con));


	$emm=$_REQUEST['EM'];
	
	$pwd1=$_REQUEST['PWD'];
	$q="select * from signup where em='$emm' && pwd='$pwd1'";
	$rs=mysqli_query($con,$q)or die("could not execute".mysqli_error($con));
	$x=mysqli_num_rows($rs);
	if($x>0)
	{
		session_start();
		$_SESSION['login']=$emm;
	header('location:home.php');
	}
	else
		echo "invalid email or password";
	
}

?>
