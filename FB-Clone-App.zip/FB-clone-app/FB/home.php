<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">


<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous">
</script>

<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

<script>


 
 
function like(str)
 {
	 
 var xmlhttp=new XMLHttpRequest();
	  xmlhttp.onreadystatechange=function(){
		  if (this.readyState==4) {
			  document.getElementById("data").innerHTML=this.responseText;
		  //alert(this.responseText);
		  //loadData();
		  }
	  };
	  xmlhttp.open("GET","getlike.php?pid="+str,true);
	  xmlhttp.send();
	 }

	 function share(pid)
 {
	 
 var xmlhttp=new XMLHttpRequest();
	  xmlhttp.onreadystatechange=function(){
		  if (this.readyState==4) {
			  document.getElementById("main").innerHTML=this.responseText;
		  //alert(this.responseText);
		  //loadData();
		  }
	  };
	  xmlhttp.open("GET","share.php?id="+pid,true);
	  xmlhttp.send();
 }

</script>

</head>

<body >

<?php
ob_start();
?>

<div class="Cont" >

<div class="row" style="height:70px; border:1px solid gray">
<div class="col-md-1"></div>
<div class="col-md-8" style="padding-top:0px; color:blue"><h4 class="display-2" ><b>facebook</b></h4></div>
<div class="col-md-3" style="font-size:35px;color:blue; padding-top:10px">
<center><i class="fa fa-search"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<i class="fab fa-facebook-messenger"></i></center>
</div>
</div>

<div class="row" style="height:40px; background:#e8ebf0">
<center><div class="col-md-3" style="font-size:30px; padding-top:5px">
<a href="home.php" style="color:blue"><i class="fa fa-home" ></i></a>
</div>
<div class="col-md-3" style="font-size:30px;color:blue; padding-top:5px">
<i class="fa fa-user-friends"></i>
</div>
<div class="col-md-3" style="font-size:30px;color:blue; padding-top:5px">
<i class="fa fa-bell"></i>
</div>
<div class="col-md-3" style="font-size:30px; padding-top:5px">
<a href="bar.php" style="color:blue"><i class="fa fa-bars"></i></a>
</div></center>
</div>

<div class="row" style="height:78px; border:1px solid gray">
<div class="col-md-2" style="color:blue">

<?php
session_start();
if(isset($_SESSION['login']))
{
$con=mysqli_connect('localhost','root','')or die("could not connect server".mysqli_error($con));
mysqli_select_db($con,'mydb')or die("could not connect database".mysqli_error($con));
$em=$_SESSION['login'];
$q="select * from signup where em='$em'";
$rs=mysqli_query($con,$q);
	$r=mysqli_fetch_array($rs);
	$img=$r[6];
	echo "<center><h3 style='margin-left:20px'><b><a href='profile.php' style='text-decoration:none;color:blue'>$r[0] $r[1]</a></b></h3></center>";
}
else
	echo "<a href='login.php'>LogIn</a>";
?>;

</div>

<div class="col-md-1">
<?php
echo "<a href='profile.php' ><img src='$img' height='100%' width='100%' style='border-radius:40px'></a>";

?>
</div>
<div class="col-md-9" style=" padding-top:20px">

<!-- Button trigger modal -->
<a href="modal.php" style="margin-left:50px"><button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" style="width:80px">
  Post
</button></a>
<!-- Modal -->
</div>
</div>
<div class="row" style="background:lightgray; height:15px"></div>

<div class="row">


<?php
$s="select * from post";
$rs1=mysqli_query($con,$s)or die("Could not execute ".mysqli_error($con));

while($r1=mysqli_fetch_array($rs1))
{
$q="select * from signup where em='$r1[1]'";
$rs=mysqli_query($con,$q);
$r=mysqli_fetch_array($rs);
$im=$r[6];
$n=$r[0];
$n2=$r[1];
?>
<div class="col-md-3" ></div>

<div class="col-md-6" id="main" style="border:2px solid gray" >

<div>
<div class="row" style="height:60px" >
<div class="col-md-2"><img src="<?php echo $im;?>" height="100%" width="100%" style="border-radius:40px""></div>
<div class="col-md-5"><div class="row" style="height:30px; padding-top:5px"><?php echo "<h4><b>$n $n2</b></h4>" ?></div>
<div class="row" style="height:30px">
<?php echo "&nbsp; $r1[2]"; ?></div>

</div>
</div>

<div class="row">
<div class="col-md-12" >
<h4>

<?php
echo $r1[3];
?>
</h4>
</div>

</div>


<div class="row" >
<div class="col-md-12" >
<img src="<?php echo $r1[4]?>" height="100%" width="100%">
</div>

</div><hr>

<div class="row" style="padding-top:0px">
<center><div class="col-md-4" >
<?php
$id=$r1[0];
$q="select * from likepost where pid=$r1[0]";
$rs2=mysqli_query($con,$q);
$x=mysqli_num_rows($rs2);
?>
<button class="btn" style="font-size:20px" <?php echo "onclick='like($id)'";?>> <i class="far fa-thumbs-up"></i>&nbsp;&nbsp;Like &nbsp; &nbsp; <?php echo $x;?></a></button>

</div>
<div class="col-md-4" >


<?php
$t="select * from comment where pid='$id'";
$u=mysqli_query($con,$t);
$v=mysqli_num_rows($u);
 
?>


<button class="btn" style="font-size:20px" data-bs-toggle="modal" data-bs-target="#exampleModal1"><?php echo "<a href='comment.php?id=$id' style='color:black; text-decoration:none'>";?> <i class="far fa-comment-dots"></i>&nbsp;&nbsp;Comment &nbsp;&nbsp;<?php echo $v;?></a></button>


</div>
<div class="col-md-3" >
<button class="btn" style="font-size:20px"><?php echo "<a href='share.php?id=$id' style='color:black; text-decoration:none'>";?><i class="far fa-share"></i>&nbsp;&nbsp;Share</a></button>


</div></center>

</div>

</div>


</div>
<div class="row" style="background:lightgray; height:15px"></div>
<br>
<?php

}
?>




</div>

</div>
</body>
</html>