<?php
if(isset($_REQUEST['pid']))
{
	session_start();
$con=mysqli_connect('localhost','root','')or die("could not connect server".mysql_error($con));
mysqli_select_db($con,'mydb')or die("could not connect database".mysql_error($con));

	$id=$_REQUEST['pid'];

$u=$_SESSION['login'];
$d=date('D/M/Y');
date_default_timezone_set('asia/calcutta');
$t=date('h/i/s');
$dt=$d.$t;
 $q="select * from likepost where pid='$id' && uname='$u'";
 $rs=mysqli_query($con,$q);
 $x=mysqli_num_rows($rs);
 if($x>0)
 {
	 //echo "couldn't like more than one time";
 }
 else
 {
 $s="insert into likepost (pid,uname,dt) values($id,'$u','$dt')";
 mysqli_query($con,$s);
 //echo "like";
 }
}
?>