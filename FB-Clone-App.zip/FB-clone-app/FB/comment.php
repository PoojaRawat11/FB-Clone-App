<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">


<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous">
</script>

<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

</head>



<div class="cont">
<div class="row" >

<div class="col-md-3" style="height:550px"></div>

<div class="col-md-6" style="height:550px;background:white;border:2px solid gray">

<div class="row" style="height:40px;background:#e8ebf0">

<div class="col-md-3">
<?php

$con=mysqli_connect('localhost','root','')or die("could not connect server".mysql_error($con));
mysqli_select_db($con,'mydb')or die("could not connect database".mysql_error($con));

$id=$_REQUEST['id'];
$q="select * from likepost where pid='$id'";
$rs2=mysqli_query($con,$q);
$x=mysqli_num_rows($rs2);
echo "<b><h2 style='padding-top:10px'><i class='far fa-thumbs-up'></i>&nbsp;&nbsp;Like &nbsp; &nbsp; $x</b>"; 

?>

</div>

</div>

<div class="row" style="height:440px;border:1px solid gray">
<div class="col-md-12" >

<?php
session_start();
  $u=$_SESSION['login'];

$a="select * from comment where pid='$id'";
$b=mysqli_query($con,$a);
$c=mysqli_num_rows($b);

if($c>0)
{

	while($d=mysqli_fetch_array($b))
	{
	$e="select * from signup where em='$u'";
	$f=mysqli_query($con,$e);
	$g=mysqli_fetch_array($f);
	$fn=$g[0];
	$ln=$g[1];
	echo "<br><b style='font-size:15px'>$fn  $ln</b>  &nbsp;&nbsp;&nbsp; $d[4]<br>";
	}
}
else
	echo "";
?>

</div>

</div>


<div class="row" style="height:70px;background:#e8ebf0">
<div class="col" style="padding-top:10px" >
<form>
<div class="row"><div class="col-md-10">
<input type="hidden" name="i" value="<?php echo $id;?>">
<textarea rows="3" cols="110" style="border-radius:20px" name="com"></textarea></div>
<div class="col-md-2">
<button class="btn" style="font-size:40px;color:blue;padding-top:8px" type="submit" name="sub"><i class="fas fa-arrow-circle-right"></i> </button> </form></div>
</div></div>

</div>

<div class="col-md-3" style="height:550px"></div>
</div>
</div>
</body>
</html>
<?php
if (isset($_REQUEST['sub']))
{
	
	date_default_timezone_set('asia/calcutta');
	$d=date('D/M/Y');
	$t=date('h/i/s');
	$dt=$d.$t;
	$id=$_REQUEST['i'];
  $comt=$_REQUEST['com'];
  
	$s="insert into comment (pid,uname,dt,text) values('$id','$u','$dt','$comt')";
	mysqli_query($con,$s);

}


?>


