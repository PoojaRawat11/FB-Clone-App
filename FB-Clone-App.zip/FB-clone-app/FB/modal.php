
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">


<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous">
</script>

<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

</head>
<body>

<div class="row" style="height:650px">

<div class="col-md-3">
</div>
<div class="col-md-6" style="height:650px; background:#e8ebf0">
<br><br>
<form method="post" enctype="multipart/form-data">
<h1 style="color:blue"><b>Post something here</b></h1><br>
<textarea rows="3" cols="80" style="border-radius:20px" name="text" placeholder="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Write something here....."></textarea><br><br>
<input type="file" name="file" style="background:skyblue"><br>
<input type="submit" name="sub" value="Post" style="background:skyblue"></div>
</form>
</div>
</body>
</html>
<?php
if(isset($_REQUEST['sub']))
{
	$con=mysqli_connect('localhost','root','')or die("could not connect server".mysql_error($con));
mysqli_select_db($con,'mydb')or die("could not connect database".mysql_error($con));
session_start();
	$text=$_REQUEST['text'];
	$img=$_FILES['file']['name'];
$em=$_SESSION['login'];
$d=date('D/M/Y');
date_default_timezone_set('asia/calcutta');
$t=date('h/i/s');


$q="select * from signup where em='$em'";
$rs=mysqli_query($con,$q)or die("could not execute".mysqli_error($con));
$r=mysqli_fetch_array($rs);
if($img=="")
{
	
$q="insert into post (uname,dt,text) values ('$em','$d $t','$text')";
$rsss=mysqli_query($con,$q);
if($rsss>0)
{
	header('location:home.php');

}
	
}
else
{
if(move_uploaded_file($_FILES['file']['tmp_name'],$_FILES['file']['name']));
{
	

$q="insert into post (uname,dt,text,img) values ('$em','$d $t','$text','$img')";
$rss=mysqli_query($con,$q)or die("could not execute".mysqli_error($con));
 if($rss>0)
 {
	 header('location:home.php');
 }
}

	
}
}
?>